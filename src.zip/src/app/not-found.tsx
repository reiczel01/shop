export default function NotFoundPage() {
    return (
        <div>Nie znaleziono strony</div>
    );
}