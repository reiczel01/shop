"use client";

export default function ErrorPage() {
  return (
    <div>
      <h1 className="mb-3 text-lg font-bold">Ups error...</h1>
      <p>Coś poszło nie tak</p>
    </div>
  );
}