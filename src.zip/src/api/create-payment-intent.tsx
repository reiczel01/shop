import { NextApiRequest, NextApiResponse } from 'next';
import Stripe from 'stripe';

const stripe = new Stripe(process.env.STRIPE_PUBLISHABLE_KEY || '');

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method Not Allowed' });
  }

  try {
    const { amount, currency } = req.body;

    if (!amount || !currency) {
      return res.status(400).json({ message: 'Amount and currency are required' });
    }

    // Tworzenie PaymentIntent z kwotą zamówienia i walutą
    const paymentIntent = await stripe.paymentIntents.create({
      amount: amount,
      currency: currency,
      // W najnowszej wersji API, ustawienie parametru `automatic_payment_methods` jest opcjonalne, ponieważ Stripe domyślnie włącza jego funkcjonalność.
      automatic_payment_methods: {
        enabled: true,
      },
    });

    res.status(200).json({
      clientSecret: paymentIntent.client_secret,
    });
  } catch (error) {
    res.status(500).json({ error: { message: (error as Error).message } });
  }
}
